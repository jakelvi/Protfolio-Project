        function imgSlider(anything) {
            document.querySelector('.pepsi').src = anything;
        }

        function changeBgColor(color) {
            const sec = document.querySelector('.sec');
            sec.style.background = color;
        }